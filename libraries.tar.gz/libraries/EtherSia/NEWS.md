Release History
===============

Version 1.0.0 (2016-07-31)
--------------------------

- Initial Release
- Neighbour Discovery Protocol / Stateless Autoconfiguration
- UDP Client and Server
- DNS Client
