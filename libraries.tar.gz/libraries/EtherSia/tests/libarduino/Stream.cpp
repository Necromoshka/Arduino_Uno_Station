#include "Stream.h"

Stream Serial;


void Stream::begin(int)
{
}
